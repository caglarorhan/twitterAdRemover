## **TwitterAdRemover**

A basic browser extension try to remove twitter promotion ads.

 
 **Tested and passed in:**

 - Chrome Version 74.0.3729.131 (Official Build) (64-bit)
 

 ---
 **First Release**
 
 **Version 2020.0.1 is currently at:**

 
 
 > Features: 
 - Change Twitter promotion ad divs display property to none.
 

  > Debugs: 
